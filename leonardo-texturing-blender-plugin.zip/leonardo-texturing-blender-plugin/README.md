# Leonardo Blender Addon

A Blender Plugin that allows you to texture any existing 3D right from Blender



How to install the plugin:

Tested in Blender 3.4

To use a Blender plugin, you need to install it as an add-on in Blender. Here's how you can do it:

1. Open Blender and go to Edit > Preferences.
2. In the Preferences window, click on the Add-ons tab.
3. Click on the Install button at the top of the window.
4. In the file dialog that appears, navigate to the location where you have saved the plugin code, select the relevant Python script file and click on Install Add-on.
5. Once the add-on is installed, you should see it appear in the Add-ons list in the Preferences window. Make sure it is enabled by checking the box next to its name.
6. Close the Preferences window and the add-on should be ready to use in Blender.